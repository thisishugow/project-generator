import os 
import sys
templates_dir = os.path.dirname(os.path.realpath(__file__))

fastapi = os.path.join(templates_dir, 'fastapi.yaml')
demo = os.path.join(templates_dir, 'demo.yaml')