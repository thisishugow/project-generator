class FolderNameMissedError(Exception):
    pass